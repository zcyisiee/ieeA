import ieet

def test_version():
    assert ieet.__version__ == "0.1.0"
