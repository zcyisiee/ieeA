import ieeet

def test_version():
    assert ieeet.__version__ == "0.1.0"
